﻿A Sample Custom Module made by M0RG4N & LFA

How to install the module after compiling it:

1. Copy SampleModule.dll to TCAdmin2\ControlPanel.MVC\bin-extensions

2. Copy HelloWorld.cshtml to ControlPanel.MVC\Views\[ThemeFolder]\Game\Service

3. Clear the contents of TCAdmin2\Cache and restart the monitor

4. You can then navigate to the module in your browser e.g http://127.0.0.1/Service/HelloWorld/1