These pages post information to billingapi.aspx to create, suspend, activate and delete game servers.

- You can do this with php using the curl commands.

- Don't use these pages directly in your application because everybody will be able to see your TCAdmin login.

- You need to enable the billing api in General Settings > API Settings. Select the servers that will be used by the billing api in the game hosting tab. If you are a reseller you need to select your packages instead of servers.

- In the sample pages configure the form to post to your billingapi.aspx by changing this:
action="http://l12.0.0.1:8880/Aspx/billingapi.aspx"

- You can check for errors in the TCAdmin\Logs\Web folder. The file names are BillingApi.LastCommand.log and {date}-api.txt.

- When the billing api accepts the "AddPendingSetup" and DeleteGameAndVoiceByBillingID commands it creates a scheduled task. You can view the task in General Settings > Scheduled Tasks. Select the "Today" view. If the task does not complete successfully you can click on it and get the error message.